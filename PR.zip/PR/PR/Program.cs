﻿using System;

namespace PR
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("///////KOLOSOV228///////");
            Console.WriteLine("1) Введите HP монстра");
            Console.WriteLine("2) Введите Power монстра");
            Console.WriteLine("///////BEST_FOR_BEST///////");



            Monster monster = new Monster();
            int sum = monster.HP + monster.Power;
            int basicHP = 100;
            int basicPower = 50;

            if (sum < 150 && sum > 2)
            {
                if (monster.HP < 101 && monster.Power < 101 && monster.HP > 1 && monster.Power > 1)
                {
                    Console.WriteLine("HP: {0} ", monster.HP);
                    Console.WriteLine("Power: {0}", monster.Power);
                    Console.WriteLine("Программа завершила работу без ошибок");
                }
                else
                {
                    Console.WriteLine("HP меньше минимального, или больше максимального - присвоенно стандартное значение: {0} ", basicHP);
                    Console.WriteLine("Power меньше минимального, или больше максимального - присвоенно стандартное значение: {0}", basicPower);
                    Console.WriteLine("Программа завершила работу с одной из ошибок: превышен максимальный лимит, меньше минимального лимита");
                    Console.WriteLine("Присвоенно стандартное значение");
                }
            }
            else
            {
                Console.WriteLine("HP меньше минимального, или больше максимального - присвоенно стандартное значение: {0} ", basicHP);
                Console.WriteLine("Power меньше минимального, или больше максимального - присвоенно стандартное значение: {0}", basicPower);
                Console.WriteLine("Программа завершила работу с одной из ошибок: превышен максимальный лимит, меньше минимального лимита");
                Console.WriteLine("Присвоенно стандартное значение");
            }
        }
    }
}
