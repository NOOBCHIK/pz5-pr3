﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PR
{
    public class Monster
    {
        public int HP = Convert.ToInt32(Console.ReadLine());
        public int Power = Convert.ToInt32(Console.ReadLine());
    }
}
