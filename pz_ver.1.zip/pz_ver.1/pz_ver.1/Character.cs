﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pz_ver._1
{
    internal class Character
    {
        public string head = "Голова";
        public string tors = "Тело";
        public string heands = "Руки";
        public string legs = "Ноги";
    }
}
