﻿using System;

namespace pz_ver._1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Monster monster = new Monster();
            Character character = new Character();
            Console.WriteLine("Здоровье монстра: {0},  Сила монстра: {1}", monster.hp, monster.power);
            Console.WriteLine("Хитбокс, в который монстр может наносить урон: {0} , {1} , {2} , {3}", character.head, character.tors, character.heands, character.legs);
        }
    }
}
