﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pz_ver._1
{
    internal class Monster
    {
        public int hp = 100;
        public int power = 50;
    }
}
